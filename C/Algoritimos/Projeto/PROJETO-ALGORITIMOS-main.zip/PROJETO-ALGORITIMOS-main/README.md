<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=00bfbf&height=120&section=header&text=Projeto+Alogritimos&fontSize=30&fontColor=00bfbf&animation=twinkling&fontAlignY=35"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=00bfbf&size=35&center=true&vCenter=true&width=1200&lines=ESTUDANTES:+GABRIEL+EIRADO,+THIAGO+LITIERY+E+PEDRO+MARQUES;CURSO:+CIÊNCIA+DA+COMPUTAÇÃO;)](https://git.io/typing-svg)
